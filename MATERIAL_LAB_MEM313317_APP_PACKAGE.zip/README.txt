MATERIAL LAB - MEM 313317 PWA

Upload index.html, manifest.webmanifest and service-worker.js to an HTTPS host such as GitHub Pages.

Laptop:
Open the HTTPS site in Chrome/Edge -> browser menu -> Install / Add to desktop.

Mobile:
Open the HTTPS site in Chrome -> three dots -> Add to Home screen / Install app.

No EXE or BAT file is included.
